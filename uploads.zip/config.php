<?php
$db_host = '127.0.0.1';
$db_name = 'img_data';
$db_user = 'img_data';
$db_pass = '12345678';
